<?php 
include("cms/engine.php");
print_image($_GET['id']) ;

?>