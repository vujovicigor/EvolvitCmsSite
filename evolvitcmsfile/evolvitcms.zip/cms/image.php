<?php 
include("engine.php");
print_image($_GET['id']) ;
?>